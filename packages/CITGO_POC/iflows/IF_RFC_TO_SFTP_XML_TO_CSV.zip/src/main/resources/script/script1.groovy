	import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message) {
    // Access Data Store service
    def dataStore = new Factory(DataStoreService.class).getService()
  //  def service = new Factory(DataStoreService.class).getService()

    // Step 1: Fetch RFC payloads from properties
    def rfcMap = [
        "RFC1": message.getProperty("RFC1") ?: "",
        "RFC2": message.getProperty("RFC2") ?: "",
        "RFC3": message.getProperty("RFC3") ?: "",
        "RFC4": message.getProperty("RFC4") ?: ""
    ]

    // Step 2: Define cycle-to-RFC mapping
    def events = [
        1: ["RFC1"],
        2: ["RFC1", "RFC2"],
        3: ["RFC1", "RFC3"],
        4: ["RFC1", "RFC2", "RFC4"],
        5: ["RFC1"],
        6: ["RFC1", "RFC2", "RFC3"]
    ]

    // Step 3: Get current index from Data Store (or default to 1)
    def indexStr = dataStore.get("RFC_CYCLE_STORE", "cycle_index")
    def index = indexStr?.toInteger() ?: 1

    // Step 4: Build payload from selected RFCs
    def payload = new StringBuilder("<root>")
    def rfcKeys = events.get(index, [])
    rfcKeys.each { key ->
        payload.append(rfcMap.get(key, ""))
    }
    payload.append("</root>")

    // Set final payload in message body
    message.setBody(payload.toString())

    // Step 5: Update index for next run
    def maxIndex = events.keySet().max()
    def nextIndex = index >= maxIndex ? 1 : index + 1
    dataStore.put("RFC_CYCLE_STORE", "cycle_index", nextIndex.toString())

    return message
}