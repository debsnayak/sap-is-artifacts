import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message GetDirectory(Message message) {
    // Get body as String
    def body = message.getBody(String)

    // Store payload in property 'RFC_Payload'
    message.setProperty("RFC_Payload", body)

    // Get integration properties
    def map = message.getProperties()
    def rfcname = map.get("RFCNAME")
    def rfcnameArchive = "${rfcname}_Archive"  // Construct archive key

    // Get ValueMapping API
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    // Value Mapping for RFCNAME → MailIDS
    def value = valueMapApi.getMappedValue(
        'Notification', 'Interface', rfcname,
        'Notification', 'MailIDS'
    )
    message.setProperty("Directory", value)

    // Value Mapping for RFCNAME_Archive → MailIDS
    def archiveValue = valueMapApi.getMappedValue(
        'Notification', 'Interface', rfcnameArchive,
        'Notification', 'MailIDS'
    )
    message.setProperty("ArchiveDirectory", archiveValue)

    return message
}
