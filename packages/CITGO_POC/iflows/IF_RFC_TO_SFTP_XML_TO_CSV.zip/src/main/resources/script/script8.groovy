import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    // Get message body
    def body = message.getBody(String)

    // Get RFCNAME property
    def properties = message.getProperties()
    def rfcName = properties.get("RFCNAME") ?: "DefaultRFC"

    // Construct attachment name
    def attachmentName = "${rfcName}_Request_Payload"

    // Log the message
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.setStringProperty("Logging#1", "Attaching payload for RFC: ${rfcName}")
        messageLog.addAttachmentAsString(attachmentName, body, "text/plain")
    }

    return message
}