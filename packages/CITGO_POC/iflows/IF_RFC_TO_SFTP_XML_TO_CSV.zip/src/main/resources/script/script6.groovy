import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message SetRFCPayload(Message message) { 
    // Get Body 
    def body = message.getBody(java.lang.String) as String;

    // Get Properties
    def map = message.getProperties();
    def rfcname = map.get("RFCNAME");

    // Get Value from Value Mapping
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def value = valueMapApi.getMappedValue('RFC', 'Value', rfcname, 'State', 'Value');


    // Set body conditionally
    if (value == "Inactive") {
        message.setBody("<root></root>");
    } else {
        message.setBody(body); // keep original body if Active or any other value
    }

    return message;
}