import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.NodeList
import java.io.ByteArrayInputStream

Message processData(Message message) {
    def body = message.getBody(String)
    def csv = ""

    try {
        // Try handling as specific document with ORDERADDRESS
        if (body.contains("<ORDERADDRESS>")) {
            csv = handleOrderAddress(body)
        } else {
            def xml = new XmlSlurper().parseText(body)
            def rootName = xml.name()

            switch (rootName) {
                case "BAPI_GL_ACC_GETDETAIL.Response":
                    csv = handleGlAccountDetail(xml)
                    break
                case "BAPI_CREDITOR_GETDETAIL.Response":
                    csv = handleCreditorGetDetail(xml)
                    break
                case "BAPI_COMPANYCODE_GET_PERIOD.Response":
                    csv = handleCompanyCodeGetPeriod(xml)
                    break
                case "BAPI_GL_ACC_EXISTENCECHECK.Response":
                    csv = handleGlAccExistenceCheck(xml)
                    break
                case "BAPI_SALESORDER_GETLIST.Response":
                    csv = handleSalesOrderGetList(xml)
                    break
                default:
                    csv = "Unknown BAPI response\n"
            }
        }
    } catch (Exception e) {
        csv = "ERROR: " + e.message
    }

    message.setBody(csv)
    return message
}

// --- Handler: ORDERADDRESS custom logic ---
String handleOrderAddress(String xmlBody) {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance()
    Document doc = factory.newDocumentBuilder().parse(new ByteArrayInputStream(xmlBody.getBytes("UTF-8")))
    doc.getDocumentElement().normalize()

    def docNumber = getElementText(doc, "DOC_NUMBER")
    def docDate = getElementText(doc, "DOC_DATE")
    def createdBy = getElementText(doc, "CREATED_BY")
    def currency = getElementText(doc, "CURRENCY")

    def csv = new StringBuilder()
    csv.append("DOC_NUMBER,DOC_DATE,CREATED_BY,CURRENCY,ADDRESS_ID,NAME,STREET,CITY,POSTL_CODE,REGION,COUNTRY\n")

    NodeList items = doc.getElementsByTagName("item")
    for (int i = 0; i < items.length; i++) {
        def item = items.item(i)
        def addressId = getElementText(item, "ADDRESS")
        def name = getElementText(item, "NAME")
        def street = getElementText(item, "STREET")
        def city = getElementText(item, "CITY")
        def postal = getElementText(item, "POSTL_CODE")
        def region = getElementText(item, "REGION")
        def country = getElementText(item, "COUNTRY")

        csv.append("\"${docNumber}\",\"${docDate}\",\"${createdBy}\",\"${currency}\",")
        csv.append("\"${addressId}\",\"${name}\",\"${street}\",\"${city}\",\"${postal}\",\"${region}\",\"${country}\"\n")
    }

    return csv.toString()
}

String getElementText(def parent, String tagName) {
    def nodeList = parent.getElementsByTagName(tagName)
    if (nodeList.length > 0 && nodeList.item(0).firstChild != null) {
        return nodeList.item(0).firstChild.nodeValue
    }
    return ""
}

// --- Handler: BAPI_GL_ACC_GETDETAIL ---
String handleGlAccountDetail(def xml) {
    def csv = new StringBuilder()
    csv << "CompanyCode,GLAccount,ShortText,LongText,ChartOfAccounts,AccountCurrency,TaxCode\n"

    def detail = xml.ACCOUNT_DETAIL
    if (detail) {
        csv << "${detail.COMP_CODE.text()},"
        csv << "${detail.GL_ACCOUNT.text()},"
        csv << "${detail.SHORT_TEXT.text()},"
        csv << "${detail.LONG_TEXT.text()},"
        csv << "${detail.CHRT_ACCTS.text()},"
        csv << "${detail.ACCT_CURR.text()},"
        csv << "${detail.TAX_CODE.text()}\n"
    }

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_CREDITOR_GETDETAIL ---
String handleCreditorGetDetail(def xml) {
    def csv = new StringBuilder()
    csv << "Vendor,CompanyCode,Clerk,Name,City,PostalCode,Country\n"

    def comp = xml.CREDITOR_COMPANY_DETAIL
    def gen = xml.CREDITOR_GENERAL_DETAIL

    csv << "${comp?.VENDOR?.text() ?: ""},"
    csv << "${comp?.COMP_CODE?.text() ?: ""},"
    csv << "${comp?.CLERK?.text() ?: ""},"
    csv << "${gen?.NAME?.text() ?: ""},"
    csv << "${gen?.CITY?.text() ?: ""},"
    csv << "${gen?.POSTL_CODE?.text() ?: ""},"
    csv << "${gen?.COUNTRY?.text() ?: ""}\n"

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_COMPANYCODE_GET_PERIOD ---
String handleCompanyCodeGetPeriod(def xml) {
    def csv = new StringBuilder()
    csv << "FiscalPeriod,FiscalYear\n"

    csv << "${xml.FISCAL_PERIOD?.text() ?: ""},${xml.FISCAL_YEAR?.text() ?: ""}\n"

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_GL_ACC_EXISTENCECHECK ---
String handleGlAccExistenceCheck(def xml) {
    def csv = new StringBuilder()
    csv << "Status,Message\n"

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "Error,${ret.MESSAGE.text()}\n"
    } else {
        csv << "Success,GL account exists\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_SALESORDER_GETLIST ---
String handleSalesOrderGetList(def xml) {
    def csv = new StringBuilder()
    csv << "SalesDoc,ItemNo,Material,ShortText,DocType,DocDate,ReqQty,ReqDate,SoldTo,Name,DocStatus,GI_Date,CreationDate,CreationTime\n"

    def orders = xml.SALES_ORDERS?.item
    if (orders) {
        orders.each { order ->
            csv << "${order.SD_DOC.text()},"
            csv << "${order.ITM_NUMBER.text()},"
            csv << "${order.MATERIAL.text()},"
            csv << "${order.SHORT_TEXT.text()},"
            csv << "${order.DOC_TYPE.text()},"
            csv << "${order.DOC_DATE.text()},"
            csv << "${order.REQ_QTY.text()},"
            csv << "${order.REQ_DATE.text()},"
            csv << "${order.SOLD_TO.text()},"
            csv << "${order.NAME.text()},"
            csv << "${order.DOC_STATUS.text()},"
            csv << "${order.GI_DATE.text()},"
            csv << "${order.CREATION_DATE.text()},"
            csv << "${order.CREATION_TIME.text()}\n"
        }
    }

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}