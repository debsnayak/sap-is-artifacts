import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import java.util.*
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

Message processData(Message message) {

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def srcAgency = "RFC"
    def srcIdentifier = "Tag"
    def tgtAgency = "SAP"
    def tgtIdentifier = "Value"

    def debugInfo = []

    // Step 1: Fetch RFC names
    def rfcNameValues = valueMapApi.getMappedValue(srcAgency, srcIdentifier, "RFCName", tgtAgency, tgtIdentifier)
    debugInfo << "RFC Name raw value: ${rfcNameValues}"

    def rfcNames = rfcNameValues?.split(",")*.trim().findAll { it } ?: []
    debugInfo << "Parsed rfcNames list size: ${rfcNames.size()}"

    def tags = ["COMPANYCODE", "GLACCT", "CUSTOMER_NUMBER", "SALES_ORGANIZATION", "POSTING_DATE","SALESDOCUMENT"]

    // Step 2: Fetch tag values for each BAPI index
    def tagValueMap = tags.collectEntries { tag ->
        def tagValues = valueMapApi.getMappedValue(srcAgency, srcIdentifier, tag, tgtAgency, tgtIdentifier)
        debugInfo << "Tag: ${tag}, raw value: ${tagValues}"
        [(tag): (tagValues?.split(",")*.trim() ?: [])]
    }

    // Step 3: Build full payload XML
    def sw = new StringWriter()
    def xml = new MarkupBuilder(sw)

    xml.root {
        rfcNames.eachWithIndex { rfcName, i ->
            if (rfcName) {
                record {
                    "ns0:${rfcName}"("xmlns:ns0": "urn:sap-com:document:sap:rfc:functions") {
                        tags.each { tag ->
                            def value = tagValueMap[tag]?.getAt(i) ?: ""
                            if (value && value != "NA") {
                                "${tag}"(value)
                            } else if (value == "") {
                                "${tag}"()
                            }
                        }
                    }
                }
            }
        }
    }

    def fullPayloadXml = sw.toString()
    debugInfo << "Generated XML Payload: ${fullPayloadXml}"

    // Step 4: Get current sequence key like "Sequence_1", "Sequence_2", etc.
    def props = message.getProperties()
    def counterStr = props.get("retrievedCounter") ?: "1"
    def counter = counterStr.toInteger()
    def sequenceKey = "Sequence_${counterStr}"

    // Step 5: Fetch list of BAPIs for current sequence step
    def bapiListStr = valueMapApi.getMappedValue("Number", "Value", sequenceKey, "RFCName", "Value")
    def bapiNames = bapiListStr?.split(",")*.trim() ?: []

    // Step 6: Filter only those records from full payload
    def parsedXml = new XmlSlurper(false, false).parseText(fullPayloadXml)
    def records = parsedXml.record

    def selectedRecords = records.findAll { rec ->
        def firstChild = rec.children().getAt(0)
        def fullName = firstChild.name().toString()
        def localName = fullName.contains(":") ? fullName.split(":")[-1] : fullName
        bapiNames.contains(localName)
    }

    // Step 7: Build filtered XML using StreamingMarkupBuilder
    def smb = new StreamingMarkupBuilder()
    smb.encoding = "UTF-8"
    def finalXml = smb.bind {
        root {
            selectedRecords.each { rec ->
                mkp.yield rec
            }
        }
    }

    // Set outputs
    message.setHeader("DebugInfo", debugInfo.join(" | "))
    message.setBody(XmlUtil.serialize(finalXml))

    // Step 8: Set next counter
    def nextCounter = (counter % 6) + 1
    message.setProperty("nextCounter", nextCounter.toString())

    return message
}