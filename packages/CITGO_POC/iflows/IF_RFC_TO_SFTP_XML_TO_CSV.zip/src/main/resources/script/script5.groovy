import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper(false, false).parseText(body)

    // Extract child elements (remove parent/root)
    def innerXml = new StreamingMarkupBuilder().bind {
        mkp.yield xml.children()
    }

    message.setBody(innerXml.toString())
    return message
}