import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String) as String

    // Remove both opening and closing <record> tags
    body = body.replaceAll("<record>", "").replaceAll("</record>", "")

    message.setBody(body)
    return message
}
