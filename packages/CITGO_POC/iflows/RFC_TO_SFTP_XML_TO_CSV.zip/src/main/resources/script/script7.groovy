import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)
    def rootName = xml.name()
    def csv = ""

    switch (rootName) {
        case "BAPI_GL_ACC_GETDETAIL.Response":
            csv = handleGlAccountDetail(xml)
            break
        case "BAPI_CREDITOR_GETDETAIL.Response":
            csv = handleCreditorGetDetail(xml)
            break
        case "BAPI_COMPANYCODE_GET_PERIOD.Response":
            csv = handleCompanyCodeGetPeriod(xml)
            break
        case "BAPI_GL_ACC_EXISTENCECHECK.Response":
            csv = handleGlAccExistenceCheck(xml)
            break
        default:
            csv = "Unknown BAPI response\n"
    }

    message.setBody(csv)
    return message
}

// --- Handler: BAPI_GL_ACC_GETDETAIL ---
String handleGlAccountDetail(def xml) {
    def csv = new StringBuilder()
    csv << "CompanyCode,GLAccount,ShortText,LongText,ChartOfAccounts,AccountCurrency,TaxCode\n"

    def detail = xml.ACCOUNT_DETAIL
    if (detail) {
        csv << "${detail.COMP_CODE.text()},"
        csv << "${detail.GL_ACCOUNT.text()},"
        csv << "${detail.SHORT_TEXT.text()},"
        csv << "${detail.LONG_TEXT.text()},"
        csv << "${detail.CHRT_ACCTS.text()},"
        csv << "${detail.ACCT_CURR.text()},"
        csv << "${detail.TAX_CODE.text()}\n"
    }

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_CREDITOR_GETDETAIL ---
String handleCreditorGetDetail(def xml) {
    def csv = new StringBuilder()
    csv << "Vendor,CompanyCode,Clerk,Name,City,PostalCode,Country\n"

    def comp = xml.CREDITOR_COMPANY_DETAIL
    def gen = xml.CREDITOR_GENERAL_DETAIL

    csv << "${comp?.VENDOR?.text() ?: ""},"
    csv << "${comp?.COMP_CODE?.text() ?: ""},"
    csv << "${comp?.CLERK?.text() ?: ""},"
    csv << "${gen?.NAME?.text() ?: ""},"
    csv << "${gen?.CITY?.text() ?: ""},"
    csv << "${gen?.POSTL_CODE?.text() ?: ""},"
    csv << "${gen?.COUNTRY?.text() ?: ""}\n"

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_COMPANYCODE_GET_PERIOD ---
String handleCompanyCodeGetPeriod(def xml) {
    def csv = new StringBuilder()
    csv << "FiscalPeriod,FiscalYear\n"

    csv << "${xml.FISCAL_PERIOD?.text() ?: ""},${xml.FISCAL_YEAR?.text() ?: ""}\n"

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "\nERROR:,${ret.MESSAGE.text()}\n"
    }

    return csv.toString()
}

// --- Handler: BAPI_GL_ACC_EXISTENCECHECK ---
String handleGlAccExistenceCheck(def xml) {
    def csv = new StringBuilder()
    csv << "Status,Message\n"

    def ret = xml.RETURN
    if (ret?.TYPE?.text() == 'E') {
        csv << "Error,${ret.MESSAGE.text()}\n"
    } else {
        csv << "Success,GL account exists\n"
    }

    return csv.toString()
}