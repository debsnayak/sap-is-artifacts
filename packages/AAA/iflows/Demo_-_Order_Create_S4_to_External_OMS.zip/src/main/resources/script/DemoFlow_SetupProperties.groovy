/**
 * DemoFlow_SetupProperties.groovy
 * ─────────────────────────────────────────────────────────────────────────────
 * Demo iFlow: Order_Create_S4_External
 * Incture Technologies | Admin & Integration CoE
 * ─────────────────────────────────────────────────────────────────────────────
 * PURPOSE : First step of the demo iFlow. Sets all framework properties so
 *           both the Retry Framework and Notification Framework are pre-configured
 *           for this specific interface. Demonstrates how a project iFlow
 *           "registers" itself with both frameworks.
 *
 * PATTERN : Call this at the start of every iFlow. Values come from:
 *           1. Externalized parameters ({{...}} placeholders)
 *           2. Incoming message headers (sender system context)
 *           3. Partner Directory (for customer-specific overrides)
 */

import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def headers = message.getHeaders()
    def props   = message.getProperties()

    // ── Generate or carry forward Correlation ID ──────────────────────────────
    def correlationId = headers.get("X-Correlation-ID")?.toString()
                     ?: headers.get("X-Request-ID")?.toString()
                     ?: props.get("CPI_CorrelationID")?.toString()
                     ?: "ORD-${new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date())}-${UUID.randomUUID().toString().take(6).toUpperCase()}"

    message.setProperty("CPI_CorrelationID", correlationId)
    message.setHeader("X-Correlation-ID", correlationId)

    // ── Interface Identity ────────────────────────────────────────────────────
    // In real project: replace hardcoded values with externalized params {{...}}
    message.setProperty("CPI_InterfaceName",   "ORD_Create_S4_to_External_v1")
    message.setProperty("CPI_SenderSystem",    "S4HANA_PRD")
    message.setProperty("CPI_ReceiverSystem",  "EXTERNAL_OMS")
    message.setProperty("CPI_Environment",     "PRD")   // DEV | QAS | PRD

    // ── Preserve Original Payload for Retry ───────────────────────────────────
    message.setProperty("CPI_OriginalPayload", message.getBody(String) ?: "")

    // ══════════════════════════════════════════════════════════════════════════
    // RETRY FRAMEWORK CONFIGURATION
    // These values feed directly into RetryDecisionEvaluator.groovy
    // Change ONLY via externalized parameters in Integration Suite designer
    // ══════════════════════════════════════════════════════════════════════════
    message.setProperty("CPI_RetryBrokerType",      "JMS")          // JMS | EVENT_MESH | AEM | RABBITMQ | KAFKA
    message.setProperty("CPI_MaxRetries",           "3")            // Max attempts before DLQ
    message.setProperty("CPI_BackoffStrategy",      "EXPONENTIAL")  // FIXED | LINEAR | EXPONENTIAL | FIBONACCI
    message.setProperty("CPI_BackoffBaseSeconds",   "10")           // Base delay in seconds
    message.setProperty("CPI_RetryQueueName",       "ORDER_RETRY_QUEUE")
    message.setProperty("CPI_DLQName",              "ORDER_DLQ")
    message.setProperty("CPI_RetryCount",           "0")            // Reset for fresh message

    // ══════════════════════════════════════════════════════════════════════════
    // NOTIFICATION FRAMEWORK CONFIGURATION
    // These values feed directly into NotificationDispatcher.groovy
    // ══════════════════════════════════════════════════════════════════════════
    message.setProperty("CPI_NotificationMode",    "TEAMS")    // EMAIL | TEAMS | SLACK | ANS | WEBHOOK | MULTI
    // For MULTI: "TEAMS,EMAIL" — sends to both channels
    // message.setProperty("CPI_NotificationMode", "TEAMS,EMAIL")

    // ── Audit log ─────────────────────────────────────────────────────────────
    def ts = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").format(new Date())
    message.setProperty("CPI_MessageStartTime", ts)

    return message
}
