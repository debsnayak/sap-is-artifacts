/**
 * ErrorHandler.groovy
 * ─────────────────────────────────────────────────────────────────────────────
 * Reusable Error Handler | Incture Technologies | Admin & Integration CoE
 * ─────────────────────────────────────────────────────────────────────────────
 * PURPOSE : Placed in the Exception Subprocess of every iFlow.
 *           Classifies the error, enriches exchange properties for the Retry
 *           and Notification frameworks, and preserves the original payload.
 *
 * USAGE   : Add as a Groovy Script step inside the Exception Subprocess.
 *           The subsequent steps call ProcessDirect to:
 *             1. /retryFramework/execute   (Retry Framework iFlow)
 *             2. /notificationFramework/send (Notification Framework iFlow)
 *
 * ERROR CLASSIFICATION:
 *   TRANSIENT → HTTP 5xx, connection timeout, socket error → eligible for retry
 *   BUSINESS  → HTTP 4xx, validation failure, mapping error → no retry
 *   UNKNOWN   → treated as TRANSIENT (safe default)
 */

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.exception.NotFoundException
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def props   = message.getProperties()
    def headers = message.getHeaders()

    // ── Capture Error Details ─────────────────────────────────────────────────
    def exception       = message.getProperty("CamelExceptionCaught")
    def errorMessage    = exception?.getMessage() ?: "Unknown error"
    def errorClass      = exception?.getClass()?.getSimpleName() ?: "UnknownException"
    def errorStack      = exception?.getCause()?.getMessage() ?: ""
    def httpStatusCode  = headers.get("CamelHttpResponseCode")?.toString() ?: "0"
    def httpStatusText  = headers.get("CamelHttpResponseText")?.toString() ?: ""
    def ts              = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").format(new Date())

    // ── Classify Error ────────────────────────────────────────────────────────
    def errorCategory = classifyError(httpStatusCode.toInteger(), errorClass, errorMessage)

    // ── Preserve Original Payload ─────────────────────────────────────────────
    // Store before any processing overwrites it
    def originalPayload = props.get("CPI_OriginalPayload") ?: message.getBody(String)
    if (!props.get("CPI_OriginalPayload")) {
        message.setProperty("CPI_OriginalPayload", originalPayload ?: "")
    }

    // ── Generate / preserve Correlation ID ───────────────────────────────────
    def correlationId = props.get("CPI_CorrelationID")
                        ?: headers.get("X-Correlation-ID")?.toString()
                        ?: headers.get("X-Request-ID")?.toString()
                        ?: "CPI-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(8)}"
    message.setProperty("CPI_CorrelationID", correlationId)

    // ── Set Error Properties ──────────────────────────────────────────────────
    message.setProperty("CPI_ErrorCategory",   errorCategory)
    message.setProperty("CPI_ErrorMessage",    errorMessage)
    message.setProperty("CPI_ErrorClass",      errorClass)
    message.setProperty("CPI_ErrorCode",       httpStatusCode)
    message.setProperty("CPI_ErrorTimestamp",  ts)
    message.setProperty("CPI_ErrorStack",      errorStack)

    // ── Build Notification Body ───────────────────────────────────────────────
    def ifaceName      = props.get("CPI_InterfaceName") ?: "Unknown Interface"
    def senderSystem   = props.get("CPI_SenderSystem")  ?: "Unknown"
    def receiverSystem = props.get("CPI_ReceiverSystem") ?: "Unknown"
    def retryCount     = props.get("CPI_RetryCount")    ?: "0"
    def maxRetries     = props.get("CPI_MaxRetries")    ?: "3"

    def notifBody = buildNotificationBody(
        errorMessage, errorClass, httpStatusCode, httpStatusText,
        ifaceName, senderSystem, receiverSystem,
        correlationId, retryCount, maxRetries,
        errorCategory, ts, originalPayload
    )

    message.setProperty("CPI_NotificationBody",     notifBody)
    message.setProperty("CPI_NotificationSubject",  "Integration Error: ${ifaceName}")
    message.setProperty("CPI_NotificationSeverity", errorCategory == "BUSINESS" ? "WARNING" : "ERROR")

    // ── Set Severity for Notification (DLQ gets highest priority) ─────────────
    def retryCountInt = retryCount.toInteger()
    def maxRetriesInt = maxRetries.toInteger()
    if (retryCountInt >= maxRetriesInt) {
        message.setProperty("CPI_NotificationSeverity", "ERROR")
        message.setProperty("CPI_NotificationSubject",  "DEAD LETTER: ${ifaceName} — Max Retries Exhausted")
    }

    return message
}

// ── Error Classification Logic ────────────────────────────────────────────────
def String classifyError(int httpCode, String exceptionClass, String errorMsg) {
    // HTTP 4xx = Business Error (no retry)
    if (httpCode >= 400 && httpCode < 500) return "BUSINESS"

    // HTTP 5xx = Transient (retry eligible)
    if (httpCode >= 500) return "TRANSIENT"

    // Exception-based classification
    def businessExceptions = [
        "ValidationException", "MappingException", "SchemaException",
        "DataFormatException", "ParseException", "InvalidFormatException"
    ]
    if (businessExceptions.any { exceptionClass.contains(it) }) return "BUSINESS"

    def transientExceptions = [
        "ConnectException", "SocketTimeoutException", "SocketException",
        "HttpHostConnectException", "ConnectionException", "TimeoutException",
        "ServiceUnavailableException", "IOException"
    ]
    if (transientExceptions.any { exceptionClass.contains(it) }) return "TRANSIENT"

    // Keyword-based fallback
    if (errorMsg?.toLowerCase()?.contains("timeout"))    return "TRANSIENT"
    if (errorMsg?.toLowerCase()?.contains("unavailable")) return "TRANSIENT"
    if (errorMsg?.toLowerCase()?.contains("connection")) return "TRANSIENT"

    return "TRANSIENT" // Default: assume transient (safer — at least try once more)
}

// ── Notification Body Builder ─────────────────────────────────────────────────
def String buildNotificationBody(String errorMsg, String errorClass, String httpCode,
                                  String httpText, String iface, String sender, String receiver,
                                  String corrId, String retryCount, String maxRetries,
                                  String category, String ts, String payload) {
    def payloadExcerpt = payload ? payload.take(300) + (payload.size() > 300 ? "... [truncated]" : "") : "N/A"
    return """
Error Category : ${category}
Error Class    : ${errorClass}
HTTP Status    : ${httpCode} ${httpText}
Error Message  : ${errorMsg}

Interface      : ${iface}
Sender System  : ${sender}
Receiver System: ${receiver}
Correlation ID : ${corrId}
Timestamp      : ${ts}
Retry Attempt  : ${retryCount} of ${maxRetries}

Payload Excerpt:
${payloadExcerpt}
""".stripLeading()
}
