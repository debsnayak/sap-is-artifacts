/**
 * RetryDecisionEvaluator.groovy
 * ─────────────────────────────────────────────────────────────────────────────
 * Reusable Retry Framework | Incture Technologies | Admin & Integration CoE
 * ─────────────────────────────────────────────────────────────────────────────
 * PURPOSE : Evaluates retry eligibility, calculates backoff delay, and sets
 *           broker-routing properties. Broker-agnostic — route decision is
 *           driven purely by CPI_RetryBrokerType property.
 *
 * INPUTS  (Exchange Properties - set by calling iFlow or ErrorHandler):
 *   CPI_RetryBrokerType     : JMS | EVENT_MESH | AEM | RABBITMQ | KAFKA
 *   CPI_MaxRetries          : integer (default: 3)
 *   CPI_BackoffStrategy     : FIXED | LINEAR | EXPONENTIAL | FIBONACCI
 *   CPI_BackoffBaseSeconds  : integer (default: 5)
 *   CPI_RetryCount          : integer (current count, incremented here)
 *   CPI_CorrelationID       : string (message tracing ID)
 *   CPI_InterfaceName       : string (e.g. CHO_Order_Create_S4_Magento)
 *   CPI_RetryQueueName      : string (broker queue/topic name for retry)
 *   CPI_DLQName             : string (dead-letter queue/topic name)
 *   CPI_ErrorCategory       : TRANSIENT | BUSINESS | INTERMITTENT
 *
 * OUTPUTS (Exchange Properties set by this script):
 *   CPI_RetryDecision       : RETRY | DLQ | NO_RETRY
 *   CPI_RetryDelaySeconds   : integer (computed backoff)
 *   CPI_RetryCount          : integer (incremented)
 *   CPI_RetryLog            : string (audit log entry)
 *   CPI_RetryAttemptLabel   : string (e.g. "Attempt 2 of 5")
 */

import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def props = message.getProperties()

    // ── Read Configuration ────────────────────────────────────────────────────
    def brokerType      = resolveConfig(props, "CPI_RetryBrokerType",    "JMS").toUpperCase()
    def maxRetries      = resolveConfig(props, "CPI_MaxRetries",         "3").toInteger()
    def backoffStrategy = resolveConfig(props, "CPI_BackoffStrategy",    "EXPONENTIAL").toUpperCase()
    def backoffBase     = resolveConfig(props, "CPI_BackoffBaseSeconds", "5").toInteger()
    def errorCategory   = resolveConfig(props, "CPI_ErrorCategory",      "TRANSIENT").toUpperCase()
    def interfaceName   = resolveConfig(props, "CPI_InterfaceName",      "UNKNOWN_INTERFACE")
    def retryQueueName  = resolveConfig(props, "CPI_RetryQueueName",     "RETRY_QUEUE_DEFAULT")
    def dlqName         = resolveConfig(props, "CPI_DLQName",            "DLQ_DEFAULT")
    def correlationId   = resolveConfig(props, "CPI_CorrelationID",      message.getMessageId() ?: UUID.randomUUID().toString())

    // Current count (from previous attempts; starts at 0)
    def currentCount = (resolveConfig(props, "CPI_RetryCount", "0")).toInteger()

    // ── Business Error: Never Retry ───────────────────────────────────────────
    if (errorCategory == "BUSINESS") {
        message.setProperty("CPI_RetryDecision",   "NO_RETRY")
        message.setProperty("CPI_RetryLog",        buildLog(correlationId, interfaceName, currentCount, maxRetries, "NO_RETRY — Business error (4xx). Routed to error handler. No retry.", 0))
        return message
    }

    // ── Increment Retry Count ─────────────────────────────────────────────────
    currentCount++
    message.setProperty("CPI_RetryCount",        currentCount.toString())
    message.setProperty("CPI_CorrelationID",     correlationId)
    message.setProperty("CPI_RetryBrokerType",   brokerType)
    message.setProperty("CPI_RetryQueueName",    retryQueueName)
    message.setProperty("CPI_DLQName",           dlqName)
    message.setProperty("CPI_RetryAttemptLabel", "Attempt ${currentCount} of ${maxRetries}")

    // ── Check Max Retries Exceeded ────────────────────────────────────────────
    if (currentCount > maxRetries) {
        message.setProperty("CPI_RetryDecision", "DLQ")
        message.setProperty("CPI_RetryDelaySeconds", "0")
        message.setProperty("CPI_RetryLog",      buildLog(correlationId, interfaceName, currentCount, maxRetries, "DLQ — Max retries (${maxRetries}) exhausted. Sending to Dead Letter Queue: ${dlqName}", 0))
        return message
    }

    // ── Calculate Backoff Delay ───────────────────────────────────────────────
    def delaySeconds = calculateBackoff(backoffStrategy, backoffBase, currentCount)
    message.setProperty("CPI_RetryDecision",      "RETRY")
    message.setProperty("CPI_RetryDelaySeconds",  delaySeconds.toString())
    message.setProperty("CPI_RetryLog",           buildLog(correlationId, interfaceName, currentCount, maxRetries, "RETRY — Broker: ${brokerType} | Queue: ${retryQueueName} | Delay: ${delaySeconds}s | Strategy: ${backoffStrategy}", delaySeconds))

    // ── Broker-Specific Header Setup ──────────────────────────────────────────
    // These headers are read by the conditional adapter endpoints downstream
    message.setProperty("CPI_BrokerRoute_JMS",        (brokerType == "JMS")        ? "true" : "false")
    message.setProperty("CPI_BrokerRoute_EventMesh",  (brokerType == "EVENT_MESH") ? "true" : "false")
    message.setProperty("CPI_BrokerRoute_AEM",        (brokerType == "AEM")        ? "true" : "false")
    message.setProperty("CPI_BrokerRoute_RabbitMQ",   (brokerType == "RABBITMQ")   ? "true" : "false")
    message.setProperty("CPI_BrokerRoute_Kafka",      (brokerType == "KAFKA")      ? "true" : "false")

    // Embed retry metadata into message headers so the consumer knows
    message.setHeader("X-CPI-Retry-Count",        currentCount.toString())
    message.setHeader("X-CPI-Retry-MaxAttempts",  maxRetries.toString())
    message.setHeader("X-CPI-Retry-Delay",        delaySeconds.toString())
    message.setHeader("X-CPI-Correlation-ID",     correlationId)
    message.setHeader("X-CPI-Interface",          interfaceName)
    message.setHeader("X-CPI-Broker",             brokerType)
    message.setHeader("X-CPI-Retry-At",           retryTimestamp(delaySeconds))

    return message
}

// ── Backoff Strategies ────────────────────────────────────────────────────────
def int calculateBackoff(String strategy, int base, int attempt) {
    switch (strategy) {
        case "FIXED":
            return base

        case "LINEAR":
            return base * attempt

        case "EXPONENTIAL":
            // Cap at 3600s (1 hour) to avoid unbounded delays
            return (int) Math.min(base * Math.pow(2, attempt - 1), 3600)

        case "FIBONACCI":
            def fib = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
            def fibMultiplier = fib[Math.min(attempt - 1, fib.size() - 1)]
            return (int) Math.min(base * fibMultiplier, 3600)

        default:
            return base
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
def String resolveConfig(Map props, String key, String defaultValue) {
    def val = props.get(key)
    return (val != null && val.toString().trim() != "") ? val.toString().trim() : defaultValue
}

def String buildLog(String corrId, String iface, int count, int max, String decision, int delay) {
    def ts = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").format(new Date())
    return "[RETRY_FRAMEWORK] ts=${ts} | corrId=${corrId} | iface=${iface} | ${decision}"
}

def String retryTimestamp(int delaySeconds) {
    def cal = Calendar.getInstance()
    cal.add(Calendar.SECOND, delaySeconds)
    return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(cal.getTime())
}
