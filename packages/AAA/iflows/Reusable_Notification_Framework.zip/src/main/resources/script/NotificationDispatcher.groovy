/**
 * NotificationDispatcher.groovy
 * ─────────────────────────────────────────────────────────────────────────────
 * Reusable Notification Framework | Incture Technologies | Admin & Integration CoE
 * ─────────────────────────────────────────────────────────────────────────────
 * PURPOSE : Formats and routes alert notifications to any configured channel.
 *           Channel is driven by CPI_NotificationMode — no code change required
 *           to add or switch channels; only configuration changes needed.
 *
 * SUPPORTED MODES:
 *   EMAIL   → Mail Adapter (SMTP)
 *   TEAMS   → MS Teams Incoming Webhook (Adaptive Card)
 *   SLACK   → Slack Incoming Webhook
 *   ANS     → SAP Alert Notification Service (BTP)
 *   WEBHOOK → Generic HTTP Webhook (configurable URL)
 *   MULTI   → Comma-separated list, e.g. "EMAIL,TEAMS" — sends to all
 *
 * INPUTS  (Exchange Properties):
 *   CPI_NotificationMode     : EMAIL | TEAMS | SLACK | ANS | WEBHOOK | MULTI
 *   CPI_NotificationSubject  : string
 *   CPI_NotificationBody     : string (detailed error/info message)
 *   CPI_NotificationSeverity : ERROR | WARNING | INFO | SUCCESS
 *   CPI_InterfaceName        : string
 *   CPI_CorrelationID        : string
 *   CPI_RetryCount           : string (optional, shown in alert)
 *   CPI_RetryDecision        : string (optional: RETRY | DLQ | NO_RETRY)
 *   CPI_Environment          : DEV | QAS | PRD (optional, prefixes subject)
 *
 * OUTPUTS:
 *   Message body set to channel-specific formatted payload
 *   CPI_NotificationRoute    : resolved primary channel for gateway routing
 *   CPI_NotificationMulti    : "true" if MULTI mode, "false" otherwise
 *   CPI_NotificationModes    : list of modes if MULTI
 *   mail.subject header (EMAIL only)
 *   Content-Type header (JSON channels)
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def props  = message.getProperties()

    // ── Read Parameters ───────────────────────────────────────────────────────
    def rawMode     = resolve(props, "CPI_NotificationMode",     "EMAIL").toUpperCase().trim()
    def subject     = resolve(props, "CPI_NotificationSubject",  "SAP Integration Alert")
    def body        = resolve(props, "CPI_NotificationBody",     "No details provided.")
    def severity    = resolve(props, "CPI_NotificationSeverity", "ERROR").toUpperCase()
    def ifaceName   = resolve(props, "CPI_InterfaceName",        "Unknown Interface")
    def corrId      = resolve(props, "CPI_CorrelationID",        "N/A")
    def retryCount  = resolve(props, "CPI_RetryCount",           "0")
    def retryDecision = resolve(props, "CPI_RetryDecision",      "")
    def environment = resolve(props, "CPI_Environment",          "PRD")
    def ts          = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z").format(new Date())

    // Enrich subject with environment prefix for non-PRD
    def enrichedSubject = (environment != "PRD") ? "[${environment}] ${subject}" : subject

    // ── MULTI Mode Handling ───────────────────────────────────────────────────
    def modes = rawMode.split(",").collect { it.trim() }.findAll { it }
    def isMulti = modes.size() > 1

    message.setProperty("CPI_NotificationMulti", isMulti ? "true" : "false")
    message.setProperty("CPI_NotificationModes", modes.join(","))

    // Primary route = first mode (gateway uses this for routing decision)
    def primaryMode = modes[0]
    message.setProperty("CPI_NotificationRoute", primaryMode)

    // ── Format for primary channel ────────────────────────────────────────────
    formatForChannel(message, primaryMode, enrichedSubject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)

    // ── Store secondary payloads for MULTI mode ───────────────────────────────
    // For MULTI, the iFlow loops through CPI_NotificationModes list via multicast
    if (isMulti) {
        modes.eachWithIndex { mode, idx ->
            def tmpMsg = [subject: enrichedSubject, body: body, severity: severity,
                         ifaceName: ifaceName, corrId: corrId, ts: ts]
            message.setProperty("CPI_NotificationPayload_${mode}", buildPayload(mode, tmpMsg, retryCount, retryDecision))
        }
    }

    return message
}

// ── Channel Formatters ────────────────────────────────────────────────────────

def void formatForChannel(Message message, String mode, String subject, String body,
                           String severity, String ifaceName, String corrId,
                           String retryCount, String retryDecision, String ts) {
    switch (mode) {
        case "EMAIL":
            formatEmail(message, subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
            break
        case "TEAMS":
            formatTeams(message, subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
            break
        case "SLACK":
            formatSlack(message, subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
            break
        case "ANS":
            formatANS(message, subject, body, severity, ifaceName, corrId, ts)
            break
        case "WEBHOOK":
        default:
            formatWebhook(message, subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
    }
}

def String buildPayload(String mode, Map ctx, String retryCount, String retryDecision) {
    // Returns serialised payload string for secondary channels in MULTI mode
    switch (mode) {
        case "TEAMS":   return buildTeamsJson(ctx.subject, ctx.body, ctx.severity, ctx.ifaceName, ctx.corrId, retryCount, retryDecision, ctx.ts)
        case "SLACK":   return buildSlackJson(ctx.subject, ctx.body, ctx.severity, ctx.ifaceName, ctx.corrId, retryCount, retryDecision, ctx.ts)
        case "ANS":     return buildANSJson(ctx.subject, ctx.body, ctx.severity, ctx.ifaceName, ctx.corrId, ctx.ts)
        case "WEBHOOK": return buildWebhookJson(ctx.subject, ctx.body, ctx.severity, ctx.ifaceName, ctx.corrId, retryCount, retryDecision, ctx.ts)
        default:        return buildEmailText(ctx.subject, ctx.body, ctx.severity, ctx.ifaceName, ctx.corrId, retryCount, retryDecision, ctx.ts)
    }
}

// ── EMAIL ─────────────────────────────────────────────────────────────────────
def void formatEmail(Message message, String subject, String body, String severity,
                     String ifaceName, String corrId, String retryCount,
                     String retryDecision, String ts) {
    def text = buildEmailText(subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
    message.setBody(text)
    message.setHeader("mail.subject", "${severityPrefix(severity)} ${subject}")
    message.setHeader("Content-Type", "text/plain; charset=UTF-8")
}

def String buildEmailText(String subject, String body, String severity,
                           String ifaceName, String corrId, String retryCount,
                           String retryDecision, String ts) {
    def retrySection = (retryCount != "0" || retryDecision != "") ?
        "\nRetry Information:\n  Attempt   : ${retryCount}\n  Decision  : ${retryDecision}\n" : ""
    return """\
SAP Integration Suite — ${severity} Alert
══════════════════════════════════════════════════════
Interface       : ${ifaceName}
Correlation ID  : ${corrId}
Timestamp       : ${ts}
Severity        : ${severity}
${retrySection}
Details:
${body}

══════════════════════════════════════════════════════
This alert was sent by the IntegrAI Notification Framework.
Powered by Incture Technologies | Admin & Integration CoE
"""
}

// ── MICROSOFT TEAMS (Adaptive Card) ──────────────────────────────────────────
def void formatTeams(Message message, String subject, String body, String severity,
                     String ifaceName, String corrId, String retryCount,
                     String retryDecision, String ts) {
    def json = buildTeamsJson(subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
    message.setBody(json)
    message.setHeader("Content-Type", "application/json")
}

def String buildTeamsJson(String subject, String body, String severity,
                           String ifaceName, String corrId, String retryCount,
                           String retryDecision, String ts) {
    def colorMap = [ERROR: "FF0000", WARNING: "FFA500", INFO: "0070F2", SUCCESS: "00A86B"]
    def themeColor = colorMap[severity] ?: "FF0000"

    // Teams Adaptive Card v1.4 (supported in all modern Teams clients)
    def card = [
        type: "message",
        attachments: [[
            contentType: "application/vnd.microsoft.card.adaptive",
            content: [
                "\$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                type: "AdaptiveCard",
                version: "1.4",
                body: [
                    [type: "TextBlock", size: "Medium", weight: "Bolder",
                     text: "${severityEmoji(severity)} ${subject}", wrap: true],
                    [type: "FactSet", facts: [
                        [title: "Interface",      value: ifaceName],
                        [title: "Severity",       value: severity],
                        [title: "Correlation ID", value: corrId],
                        [title: "Timestamp",      value: ts],
                        (retryCount != "0") ? [title: "Retry Attempt", value: retryCount] : null,
                        (retryDecision != "") ? [title: "Retry Decision", value: retryDecision] : null
                    ].findAll { it != null }],
                    [type: "TextBlock", text: "**Details:**", weight: "Bolder"],
                    [type: "TextBlock", text: body, wrap: true, color: "Attention"]
                ],
                msteams: [width: "Full"]
            ]
        ]]
    ]
    return JsonOutput.toJson(card)
}

// ── SLACK ─────────────────────────────────────────────────────────────────────
def void formatSlack(Message message, String subject, String body, String severity,
                     String ifaceName, String corrId, String retryCount,
                     String retryDecision, String ts) {
    def json = buildSlackJson(subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
    message.setBody(json)
    message.setHeader("Content-Type", "application/json")
}

def String buildSlackJson(String subject, String body, String severity,
                           String ifaceName, String corrId, String retryCount,
                           String retryDecision, String ts) {
    def colorMap  = [ERROR: "danger", WARNING: "warning", INFO: "#0070F2", SUCCESS: "good"]
    def emojiMap  = [ERROR: ":red_circle:", WARNING: ":warning:", INFO: ":information_source:", SUCCESS: ":white_check_mark:"]

    def fields = [
        [title: "Interface",      value: ifaceName,  short: true],
        [title: "Severity",       value: severity,   short: true],
        [title: "Correlation ID", value: corrId,     short: false],
        [title: "Timestamp",      value: ts,         short: false],
    ]
    if (retryCount != "0") fields << [title: "Retry Attempt", value: retryCount, short: true]
    if (retryDecision != "") fields << [title: "Retry Decision", value: retryDecision, short: true]

    def payload = [
        text: "${emojiMap[severity] ?: ':red_circle:'} *SAP Integration Suite Alert*",
        attachments: [[
            color: colorMap[severity] ?: "danger",
            title: subject,
            text: body,
            fields: fields,
            footer: "IntegrAI Notification Framework",
            ts: (System.currentTimeMillis() / 1000).toLong()
        ]]
    ]
    return JsonOutput.toJson(payload)
}

// ── SAP ALERT NOTIFICATION SERVICE ───────────────────────────────────────────
def void formatANS(Message message, String subject, String body, String severity,
                   String ifaceName, String corrId, String ts) {
    def json = buildANSJson(subject, body, severity, ifaceName, corrId, ts)
    message.setBody(json)
    message.setHeader("Content-Type", "application/json")
}

def String buildANSJson(String subject, String body, String severity,
                         String ifaceName, String corrId, String ts) {
    def severityMap = [ERROR: "ERROR", WARNING: "WARNING", INFO: "INFO", SUCCESS: "INFO"]
    def categoryMap = [ERROR: "ALERT", WARNING: "NOTIFICATION", INFO: "NOTIFICATION", SUCCESS: "NOTIFICATION"]
    def priorityMap = [ERROR: 1, WARNING: 2, INFO: 3, SUCCESS: 4]

    def payload = [
        eventType:      "CPI_Integration_Alert",
        eventTimestamp: ts,
        severity:       severityMap[severity]  ?: "ERROR",
        category:       categoryMap[severity]  ?: "ALERT",
        priority:       priorityMap[severity]  ?: 1,
        subject:        subject,
        body:           body,
        resource: [
            resourceName:     ifaceName,
            resourceType:     "CPI_Integration_Flow",
            resourceInstance: corrId,
            tags: [
                correlationId: corrId,
                interface:     ifaceName,
                framework:     "IntegrAI_Notification_v1"
            ]
        ]
    ]
    return JsonOutput.toJson(payload)
}

// ── GENERIC WEBHOOK ───────────────────────────────────────────────────────────
def void formatWebhook(Message message, String subject, String body, String severity,
                       String ifaceName, String corrId, String retryCount,
                       String retryDecision, String ts) {
    def json = buildWebhookJson(subject, body, severity, ifaceName, corrId, retryCount, retryDecision, ts)
    message.setBody(json)
    message.setHeader("Content-Type", "application/json")
}

def String buildWebhookJson(String subject, String body, String severity,
                             String ifaceName, String corrId, String retryCount,
                             String retryDecision, String ts) {
    def payload = [
        source:    "SAP_Integration_Suite",
        framework: "IntegrAI_Notification_v1",
        severity:  severity,
        subject:   subject,
        body:      body,
        metadata: [
            interface:      ifaceName,
            correlationId:  corrId,
            timestamp:      ts,
            retryCount:     retryCount,
            retryDecision:  retryDecision
        ]
    ]
    return JsonOutput.toJson(payload)
}

// ── Utility ───────────────────────────────────────────────────────────────────
def String severityPrefix(String sev) {
    def map = [ERROR: "[ERROR]", WARNING: "[WARN]", INFO: "[INFO]", SUCCESS: "[OK]"]
    return map[sev] ?: "[ALERT]"
}

def String severityEmoji(String sev) {
    def map = [ERROR: "🔴", WARNING: "🟡", INFO: "🔵", SUCCESS: "🟢"]
    return map[sev] ?: "🔴"
}

def String resolve(Map props, String key, String def_) {
    def val = props.get(key)
    return (val != null && val.toString().trim() != "") ? val.toString().trim() : def_
}
