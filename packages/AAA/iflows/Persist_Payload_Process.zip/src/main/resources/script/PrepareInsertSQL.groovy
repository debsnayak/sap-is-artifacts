/*
 * PrepareInsertSQL.groovy
 * -----------------------
 * Builds an XML payload conforming to the SAP CPI JDBC receiver
 * "XML SQL Format" (action=INSERT) for the IS_MESSAGE_METADATA table.
 * After this script runs, the body is the SQL XML that the JDBC
 * adapter executes against HANA Cloud.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    // --- Pull metadata properties prepared by BuildMetadata.groovy -----------
    String messageId       = (message.getProperty("MessageID")           ?: "") as String
    String correlationId   = (message.getProperty("CorrelationID")       ?: messageId) as String
    String businessKey     = (message.getProperty("BusinessKey")         ?: "") as String
    String senderParty     = (message.getProperty("SenderParty")         ?: "UNKNOWN") as String
    String receiverParty   = (message.getProperty("ReceiverParty")       ?: "UNKNOWN") as String
    String messageType     = (message.getProperty("MessageType")         ?: "GENERIC") as String
    String interfaceId     = (message.getProperty("InterfaceID")         ?: "GENERIC") as String
    String createdAt       = (message.getProperty("CreatedAtUTC")        ?: "") as String
    String payloadSize     = (message.getProperty("PayloadSize")         ?: "0") as String
    String sha256          = (message.getProperty("PayloadSHA256")       ?: "") as String
    String objectKey       = (message.getProperty("ObjectStoreKey")      ?: "") as String
    String objectRef       = (message.getProperty("ObjectStoreReference")?: "") as String
    String contentType     = (message.getProperty("OriginalContentType") ?: "application/octet-stream") as String
    String retentionDays   = (message.getProperty("RetentionDays")       ?: "30") as String
    String persistStatus   = (message.getProperty("PersistStatus")       ?: "PERSISTED") as String
    String tenantId        = (message.getProperty("SAP_TenantId")        ?: "DEFAULT") as String

    // XML-escape helper (covers the only characters that matter inside element text)
    def esc = { String s -> s == null ? "" :
        s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;") }

    // --- Build the JDBC XML SQL Format INSERT --------------------------------
    String sqlXml = """<?xml version="1.0" encoding="UTF-8"?>
<root>
  <IS_MESSAGE_METADATA action="INSERT">
    <table>IS_MESSAGE_METADATA</table>
    <access>
      <MESSAGE_ID>${esc(messageId)}</MESSAGE_ID>
      <CORRELATION_ID>${esc(correlationId)}</CORRELATION_ID>
      <BUSINESS_KEY>${esc(businessKey)}</BUSINESS_KEY>
      <SENDER_PARTY>${esc(senderParty)}</SENDER_PARTY>
      <RECEIVER_PARTY>${esc(receiverParty)}</RECEIVER_PARTY>
      <MESSAGE_TYPE>${esc(messageType)}</MESSAGE_TYPE>
      <INTERFACE_ID>${esc(interfaceId)}</INTERFACE_ID>
      <CONTENT_TYPE>${esc(contentType)}</CONTENT_TYPE>
      <PAYLOAD_SIZE>${esc(payloadSize)}</PAYLOAD_SIZE>
      <PAYLOAD_SHA256>${esc(sha256)}</PAYLOAD_SHA256>
      <OBJECT_STORE_KEY>${esc(objectKey)}</OBJECT_STORE_KEY>
      <OBJECT_STORE_REF>${esc(objectRef)}</OBJECT_STORE_REF>
      <STATUS>${esc(persistStatus)}</STATUS>
      <CREATED_AT>${esc(createdAt)}</CREATED_AT>
      <RETENTION_DAYS>${esc(retentionDays)}</RETENTION_DAYS>
      <TENANT_ID>${esc(tenantId)}</TENANT_ID>
    </access>
  </IS_MESSAGE_METADATA>
</root>"""

    message.setBody(sqlXml)
    message.setHeader("Content-Type", "application/xml")
    return message
}
