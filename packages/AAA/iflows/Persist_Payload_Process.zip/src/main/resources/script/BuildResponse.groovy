/*
 * BuildResponse.groovy
 * --------------------
 * Restores the original payload bytes (so the caller iFlow continues
 * with the unchanged Body) and returns persistence metadata via headers.
 * The body returned by ProcessDirect to the caller is the ORIGINAL payload,
 * not the persistence response - this keeps the reusable iFlow transparent.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    // Restore original payload bytes captured before Object Store PUT
    def original = message.getProperty("OriginalPayloadBytes")
    if (original instanceof byte[]) {
        message.setBody(original as byte[])
    }

    // Restore original Content-Type
    String ct = (message.getProperty("OriginalContentType") ?: "application/octet-stream") as String
    message.setHeader("Content-Type", ct)

    // Surface persistence outcome as headers for the caller
    message.setHeader("X-Persist-MessageID",      message.getProperty("MessageID")            ?: "")
    message.setHeader("X-Persist-ObjectKey",      message.getProperty("ObjectStoreKey")       ?: "")
    message.setHeader("X-Persist-ObjectRef",      message.getProperty("ObjectStoreReference") ?: "")
    message.setHeader("X-Persist-PayloadSize",    message.getProperty("PayloadSize")          ?: "0")
    message.setHeader("X-Persist-SHA256",         message.getProperty("PayloadSHA256")        ?: "")
    message.setHeader("X-Persist-CreatedAt",      message.getProperty("CreatedAtUTC")         ?: "")
    message.setHeader("X-Persist-Status",         "PERSISTED")

    return message
}
