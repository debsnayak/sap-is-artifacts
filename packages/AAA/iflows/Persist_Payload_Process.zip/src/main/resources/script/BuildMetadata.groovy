/*
 * BuildMetadata.groovy
 * --------------------
 * Reusable iFlow - Option D Split Storage
 * Captures payload, computes size & hash, builds Object Store key,
 * and stashes payload bytes in a property so the original Body can be
 * restored later for downstream processing.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.security.MessageDigest
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.UUID

Message processData(Message message) {

    // --- 1. Capture payload bytes (idempotent: reuse if already captured) -----
    byte[] payloadBytes
    def existing = message.getProperty("OriginalPayloadBytes")
    if (existing instanceof byte[]) {
        payloadBytes = existing as byte[]
    } else {
        def body = message.getBody(byte[].class)
        payloadBytes = (body == null) ? new byte[0] : body
        message.setProperty("OriginalPayloadBytes", payloadBytes)
    }

    // --- 2. MessageID (use MPL ID by default; allow override via header) ------
    def headers = message.getHeaders()
    def msgId = headers.get("SAP_MessageProcessingLogID") as String
    if (!msgId) {
        msgId = UUID.randomUUID().toString()
    }
    message.setProperty("MessageID", msgId)

    // --- 3. Timestamps --------------------------------------------------------
    def nowUtc = OffsetDateTime.now(ZoneOffset.UTC)
    def isoTs  = nowUtc.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
    def yyyy   = nowUtc.format(DateTimeFormatter.ofPattern("yyyy"))
    def mm     = nowUtc.format(DateTimeFormatter.ofPattern("MM"))
    def dd     = nowUtc.format(DateTimeFormatter.ofPattern("dd"))
    message.setProperty("CreatedAtUTC", isoTs)

    // --- 4. Size & SHA-256 hash ----------------------------------------------
    int size = payloadBytes.length
    String sha256 = MessageDigest.getInstance("SHA-256")
                        .digest(payloadBytes)
                        .encodeHex()
                        .toString()
    message.setProperty("PayloadSize", String.valueOf(size))
    message.setProperty("PayloadSHA256", sha256)

    // --- 5. Object Store key (hierarchical: interface/year/month/day/uuid) ---
    String iface = (message.getProperty("InterfaceID") ?: "GENERIC") as String
    String safeIface = iface.replaceAll('[^A-Za-z0-9_\\-]', '_')
    String objectKey = "${safeIface}/${yyyy}/${mm}/${dd}/${msgId}.bin"
    message.setProperty("ObjectStoreKey", objectKey)

    // --- 6. Object Store reference URI (stored in HANA for retrieval) --------
    // Map placeholder syntax: real value is resolved by adapter at runtime.
    message.setProperty("ObjectStoreReference", "os://${objectKey}")

    // --- 7. Status ------------------------------------------------------------
    message.setProperty("PersistStatus", "PENDING")

    // --- 8. Set body to payload bytes for the Object Store PUT ---------------
    message.setBody(payloadBytes)
    String contentType = (message.getProperty("OriginalContentType") ?: "application/octet-stream") as String
    message.setHeader("Content-Type", contentType)

    return message
}
